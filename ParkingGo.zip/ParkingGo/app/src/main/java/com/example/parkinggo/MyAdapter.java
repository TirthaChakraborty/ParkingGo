package com.example.parkinggo;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;

//import io.realm.RealmBasedRecyclerViewAdapter;
//import io.realm.RealmResults;
//import io.realm.RealmViewHolder;

//public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
//    private Context mcontext;
//    private RealmResults<Booking> mbooking;
//
//    //OnItemClickListener mlistener;
//
//    public MyAdapter(RealmResults<Booking> mbooking) {
//
//        this.mbooking = mbooking;
//
//    }
//    public interface OnItemClickListener
//    {
//        public int onButtonClick(int position);
//        public void onItemClick(int position);
//
//    }

//    @NonNull
//    @Override
//    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
//        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recyclerview_item, viewGroup, false);
////        Log.i("adapter","view holder called");
//        return new ViewHolder(view);
//
//
//
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull  ViewHolder holder,int position) {
//        Booking book = mbooking.get(position); //each booking object
//        holder.cn.setText(book.getCarNo());
//        holder.cm.setText(book.getCarModel());
//        holder.label1.setText("Date");
//        holder.label2.setText("Time");
//        holder.bookdate.setText(new SimpleDateFormat().format(book.getDateFrom()));
//        holder.booktime.setText(book.getTimeFrom() + " to " + book.getTimeTo());
//
//
//    }
//
//
//    @Override
//    public int getItemCount() {
//        return mbooking.size();
//    }
//
//
//    public class ViewHolder extends RecyclerView.ViewHolder {
//        //  private TextView ;
//        public TextView cn, cm;
//        public TextView bookdate;
//        public TextView booktime;
//        public TextView label1;
//        public TextView label2;
//        public RelativeLayout item;
//
//        //private OnItemClickListener mitem;
//
//        public ViewHolder(@NonNull View itemView) {
//            super(itemView);
//            cn = itemView.findViewById(R.id.carnum);
//            cm = itemView.findViewById(R.id.carmod);
//            label1 = itemView.findViewById(R.id.dateLabel);
//            bookdate = itemView.findViewById(R.id.date);
//            label2 = itemView.findViewById(R.id.timeLabel);
//            booktime = itemView.findViewById(R.id.time);
//            item = itemView.findViewById(R.id.background);
//
//
//        }
//    }
//}







//public class MyAdapter
//        extends RealmBasedRecyclerViewAdapter<Booking, MyAdapter.ViewHolder> {
//
//    public class ViewHolder extends RealmViewHolder {
//        public TextView cn, cm;
//        public TextView bookdate;
//        public TextView booktime;
//        public TextView label1;
//        public TextView label2;
//        public RelativeLayout item;
////
//        public TextView todoTextView;
//        public ViewHolder(FrameLayout container) {
//            super(container);
//            cn = itemView.findViewById(R.id.carnum);
//            cm = itemView.findViewById(R.id.carmod);
//            label1 = itemView.findViewById(R.id.dateLabel);
//            bookdate = itemView.findViewById(R.id.date);
//            label2 = itemView.findViewById(R.id.timeLabel);
//            booktime = itemView.findViewById(R.id.time);
//            item = itemView.findViewById(R.id.background);
//        }
//    }
//
//    public MyAdapter(
//            PrevBookingFragment context,
//            RealmResults<Booking> realmResults,
//            boolean automaticUpdate,
//            boolean animateResults) {
//        super(context, realmResults, automaticUpdate, animateResults);
//    }
//
//    @Override
//    public ViewHolder onCreateRealmViewHolder(ViewGroup viewGroup, int viewType) {
//        View v = inflater.inflate(R.layout.fragment_prevbooking, viewGroup, false);
//        ViewHolder vh = new ViewHolder((FrameLayout) v);
//        return vh;
//    }
//
//    @Override
//    public void onBindRealmViewHolder(ViewHolder holder, int position) {
//        final Booking book = realmResults.get(position);
//
//        holder.cn.setText(book.getCarNo());
//        holder.cm.setText(book.getCarModel());
//        holder.label1.setText("Date");
//        holder.label2.setText("Time");
//        holder.bookdate.setText(new SimpleDateFormat().format(book.getDateFrom()));
//        holder.booktime.setText(book.getTimeFrom() + " to " + book.getTimeTo());
//
//
//    }
//}