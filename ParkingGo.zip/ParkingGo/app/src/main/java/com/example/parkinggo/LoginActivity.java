package com.example.parkinggo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;

public class LoginActivity extends Activity {

    private Context mcontext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_pg);
        mcontext=this;

    }

    public void login(View view){
        Intent intent = new Intent(mcontext, Dashboard.class);
        startActivity(intent);
    }

}